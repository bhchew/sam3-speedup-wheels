# pyre-ignore-all-errors
from .connected_components import get_connected_components

__all__ = ["get_connected_components"]
