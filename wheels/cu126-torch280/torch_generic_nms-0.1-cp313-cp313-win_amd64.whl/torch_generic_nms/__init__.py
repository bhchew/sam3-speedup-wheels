# pyre-ignore-all-errors
from .generic_nms import generic_nms

__all__ = ["generic_nms"]
